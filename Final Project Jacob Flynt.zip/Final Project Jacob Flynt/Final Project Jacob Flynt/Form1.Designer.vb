﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblSite = New Label()
        lblNumNights = New Label()
        lblSub = New Label()
        lblTaxes = New Label()
        lblWithout = New Label()
        lblOptional = New Label()
        txtNumNights = New TextBox()
        txtSub = New TextBox()
        txtTaxes = New TextBox()
        txtWithout = New TextBox()
        CboSite = New ComboBox()
        BtnCalculate = New Button()
        BtnMeal = New Button()
        btnClear = New Button()
        btnExit = New Button()
        radAAA = New RadioButton()
        radMilitary = New RadioButton()
        radNone = New RadioButton()
        grpDiscounts = New GroupBox()
        txtOptional = New TextBox()
        PictureBox1 = New PictureBox()
        Label1 = New Label()
        grpDiscounts.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblSite
        ' 
        lblSite.AutoSize = True
        lblSite.Location = New Point(47, 496)
        lblSite.Name = "lblSite"
        lblSite.Size = New Size(87, 20)
        lblSite.TabIndex = 0
        lblSite.Text = "Type of Site"
        ' 
        ' lblNumNights
        ' 
        lblNumNights.AutoSize = True
        lblNumNights.Location = New Point(47, 553)
        lblNumNights.Name = "lblNumNights"
        lblNumNights.Size = New Size(125, 20)
        lblNumNights.TabIndex = 1
        lblNumNights.Text = "Number of nights"
        lblNumNights.Visible = False
        ' 
        ' lblSub
        ' 
        lblSub.AutoSize = True
        lblSub.Location = New Point(461, 477)
        lblSub.Name = "lblSub"
        lblSub.Size = New Size(256, 20)
        lblSub.TabIndex = 2
        lblSub.Text = "Subtotal Billing Amount for Your Stay"
        lblSub.Visible = False
        ' 
        ' lblTaxes
        ' 
        lblTaxes.AutoSize = True
        lblTaxes.Location = New Point(461, 529)
        lblTaxes.Name = "lblTaxes"
        lblTaxes.Size = New Size(132, 20)
        lblTaxes.TabIndex = 3
        lblTaxes.Text = "Taxes for Your Stay"
        lblTaxes.Visible = False
        ' 
        ' lblWithout
        ' 
        lblWithout.AutoSize = True
        lblWithout.Location = New Point(461, 581)
        lblWithout.Name = "lblWithout"
        lblWithout.Size = New Size(189, 20)
        lblWithout.TabIndex = 4
        lblWithout.Text = "Final Total w/out Meal Plan"
        lblWithout.Visible = False
        ' 
        ' lblOptional
        ' 
        lblOptional.AutoSize = True
        lblOptional.Location = New Point(461, 636)
        lblOptional.Name = "lblOptional"
        lblOptional.Size = New Size(240, 20)
        lblOptional.TabIndex = 5
        lblOptional.Text = "Final Total with Optional Meal Plan"
        lblOptional.Visible = False
        ' 
        ' txtNumNights
        ' 
        txtNumNights.Location = New Point(189, 547)
        txtNumNights.Name = "txtNumNights"
        txtNumNights.Size = New Size(47, 27)
        txtNumNights.TabIndex = 7
        txtNumNights.Visible = False
        ' 
        ' txtSub
        ' 
        txtSub.Location = New Point(755, 469)
        txtSub.Name = "txtSub"
        txtSub.Size = New Size(125, 27)
        txtSub.TabIndex = 8
        txtSub.Visible = False
        ' 
        ' txtTaxes
        ' 
        txtTaxes.Location = New Point(755, 529)
        txtTaxes.Name = "txtTaxes"
        txtTaxes.Size = New Size(125, 27)
        txtTaxes.TabIndex = 9
        txtTaxes.Visible = False
        ' 
        ' txtWithout
        ' 
        txtWithout.Location = New Point(755, 579)
        txtWithout.Name = "txtWithout"
        txtWithout.Size = New Size(125, 27)
        txtWithout.TabIndex = 10
        txtWithout.Visible = False
        ' 
        ' CboSite
        ' 
        CboSite.FormattingEnabled = True
        CboSite.Items.AddRange(New Object() {"tents ($30)", "", "RV ($50)", "", "cabin ($100)"})
        CboSite.Location = New Point(139, 493)
        CboSite.Name = "CboSite"
        CboSite.Size = New Size(151, 28)
        CboSite.TabIndex = 11
        CboSite.Text = "Select a site"
        ' 
        ' BtnCalculate
        ' 
        BtnCalculate.Location = New Point(331, 732)
        BtnCalculate.Name = "BtnCalculate"
        BtnCalculate.Size = New Size(130, 29)
        BtnCalculate.TabIndex = 12
        BtnCalculate.Text = "Calculate Cost"
        BtnCalculate.UseVisualStyleBackColor = True
        BtnCalculate.Visible = False
        ' 
        ' BtnMeal
        ' 
        BtnMeal.Location = New Point(487, 732)
        BtnMeal.Name = "BtnMeal"
        BtnMeal.Size = New Size(120, 29)
        BtnMeal.TabIndex = 13
        BtnMeal.Text = "Add Meal Plan"
        BtnMeal.UseVisualStyleBackColor = True
        BtnMeal.Visible = False
        ' 
        ' btnClear
        ' 
        btnClear.Location = New Point(637, 732)
        btnClear.Name = "btnClear"
        btnClear.Size = New Size(94, 29)
        btnClear.TabIndex = 14
        btnClear.Text = "Clear"
        btnClear.UseVisualStyleBackColor = True
        btnClear.Visible = False
        ' 
        ' btnExit
        ' 
        btnExit.Location = New Point(755, 732)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(94, 29)
        btnExit.TabIndex = 15
        btnExit.Text = "Exit"
        btnExit.UseVisualStyleBackColor = True
        btnExit.Visible = False
        ' 
        ' radAAA
        ' 
        radAAA.AutoSize = True
        radAAA.Location = New Point(21, 33)
        radAAA.Name = "radAAA"
        radAAA.Size = New Size(60, 24)
        radAAA.TabIndex = 17
        radAAA.TabStop = True
        radAAA.Text = "AAA"
        radAAA.UseVisualStyleBackColor = True
        ' 
        ' radMilitary
        ' 
        radMilitary.AutoSize = True
        radMilitary.Location = New Point(21, 65)
        radMilitary.Name = "radMilitary"
        radMilitary.Size = New Size(84, 24)
        radMilitary.TabIndex = 18
        radMilitary.TabStop = True
        radMilitary.Text = "Military "
        radMilitary.UseVisualStyleBackColor = True
        ' 
        ' radNone
        ' 
        radNone.AutoSize = True
        radNone.Location = New Point(21, 95)
        radNone.Name = "radNone"
        radNone.Size = New Size(66, 24)
        radNone.TabIndex = 19
        radNone.TabStop = True
        radNone.Text = "None"
        radNone.UseVisualStyleBackColor = True
        ' 
        ' grpDiscounts
        ' 
        grpDiscounts.Controls.Add(radAAA)
        grpDiscounts.Controls.Add(radNone)
        grpDiscounts.Controls.Add(radMilitary)
        grpDiscounts.Location = New Point(27, 636)
        grpDiscounts.Name = "grpDiscounts"
        grpDiscounts.Size = New Size(250, 125)
        grpDiscounts.TabIndex = 20
        grpDiscounts.TabStop = False
        grpDiscounts.Text = "Discounts"
        grpDiscounts.Visible = False
        ' 
        ' txtOptional
        ' 
        txtOptional.Location = New Point(755, 629)
        txtOptional.Name = "txtOptional"
        txtOptional.Size = New Size(125, 27)
        txtOptional.TabIndex = 21
        txtOptional.Visible = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.p6989
        PictureBox1.Location = New Point(283, 131)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(534, 295)
        PictureBox1.TabIndex = 22
        PictureBox1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(322, 43)
        Label1.Name = "Label1"
        Label1.Size = New Size(438, 46)
        Label1.TabIndex = 23
        Label1.Text = "Paul B Johson Campground "
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(1226, 821)
        Controls.Add(Label1)
        Controls.Add(PictureBox1)
        Controls.Add(txtOptional)
        Controls.Add(grpDiscounts)
        Controls.Add(btnExit)
        Controls.Add(btnClear)
        Controls.Add(BtnMeal)
        Controls.Add(BtnCalculate)
        Controls.Add(CboSite)
        Controls.Add(txtWithout)
        Controls.Add(txtTaxes)
        Controls.Add(txtSub)
        Controls.Add(txtNumNights)
        Controls.Add(lblOptional)
        Controls.Add(lblWithout)
        Controls.Add(lblTaxes)
        Controls.Add(lblSub)
        Controls.Add(lblNumNights)
        Controls.Add(lblSite)
        Name = "Form1"
        Text = "Campground"
        grpDiscounts.ResumeLayout(False)
        grpDiscounts.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblSite As Label
    Friend WithEvents lblNumNights As Label
    Friend WithEvents lblSub As Label
    Friend WithEvents lblTaxes As Label
    Friend WithEvents lblWithout As Label
    Friend WithEvents lblOptional As Label
    Friend WithEvents txtNumNights As TextBox
    Friend WithEvents txtSub As TextBox
    Friend WithEvents txtTaxes As TextBox
    Friend WithEvents txtWithout As TextBox
    Friend WithEvents CboSite As ComboBox
    Friend WithEvents BtnCalculate As Button
    Friend WithEvents BtnMeal As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents radAAA As RadioButton
    Friend WithEvents radMilitary As RadioButton
    Friend WithEvents radNone As RadioButton
    Friend WithEvents grpDiscounts As GroupBox
    Friend WithEvents txtOptional As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label1 As Label

End Class
