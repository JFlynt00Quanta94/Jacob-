﻿Imports System.Reflection.Metadata.Ecma335

Public Class Form1

    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles BtnCalculate.Click
        ' Variables
        Dim sitePrice As Decimal = 0D
        Dim nights As Integer = 0
        Dim discount As Decimal = 0D
        Dim subtotal As Decimal = 0D
        Dim taxRate As Decimal = 0.065D ' 6.5% tax rate
        Dim taxAmount As Decimal = 0D
        Dim mealPlanCost As Decimal = 0D
        Dim finalTotalWithoutMealPlan As Decimal = 0D
        Dim finalTotalWithMealPlan As Decimal = 0D

        ' Validate the number of nights
        If Not Integer.TryParse(txtNumNights.Text, nights) OrElse nights <= 0 Then
            MessageBox.Show("Enter a valid number of nights.")
            Exit Sub
        End If

        ' Determine site price based on selected site type
        Select Case CboSite.SelectedIndex
            Case 0 : sitePrice = 30D ' Tent
            Case 1 : sitePrice = 50D ' RV
            Case 2 : sitePrice = 100D ' Cabin
            Case Else
                MessageBox.Show("Select a valid site type.")
                Exit Sub
        End Select

        ' Determine discount based on selection
        If radAAA.Checked Then
            discount = 0.1D ' 10% discount
        ElseIf radMilitary.Checked Then
            discount = 0.12D ' 12% discount
        Else
            discount = 0D ' No discount
        End If

        ' Calculate subtotal
        subtotal = sitePrice * nights * (1 - discount)

        ' Calculate taxes
        taxAmount = subtotal * taxRate

        ' Check if a meal plan is already selected
        If Not String.IsNullOrEmpty(txtOptional.Text) Then
            If Decimal.TryParse(txtOptional.Text.Replace("Meal Plan: $", ""), mealPlanCost) Then
                ' Meal plan cost is already stored
            Else
                mealPlanCost = 0D ' If parsing fails, reset meal plan cost
            End If
        End If

        ' Calculate final totals
        finalTotalWithoutMealPlan = subtotal + taxAmount
        finalTotalWithMealPlan = finalTotalWithoutMealPlan + mealPlanCost

        ' Round values
        subtotal = Math.Round(subtotal, 2)
        taxAmount = Math.Round(taxAmount, 2)
        mealPlanCost = Math.Round(mealPlanCost, 2)
        finalTotalWithoutMealPlan = Math.Round(finalTotalWithoutMealPlan, 2)
        finalTotalWithMealPlan = Math.Round(finalTotalWithMealPlan, 2)

        ' Display results
        txtSub.Text = "Subtotal: $" & subtotal.ToString("F2")
        txtTaxes.Text = "Taxes: $" & taxAmount.ToString("F2")
        txtWithout.Text = "Final Total: $" & finalTotalWithoutMealPlan.ToString("F2")
        txtOptional.Text = "Meal Plan: $" & mealPlanCost.ToString("F2")
        txtOptional.Text = "Final Total: $" & finalTotalWithMealPlan.ToString("F2")
    End Sub




    Private Sub BtnMeal_Click(sender As Object, e As EventArgs) Handles BtnMeal.Click
        ' Variables
        Dim numPeople As Integer
        Dim ratePerPerson As Decimal
        Dim mealPlanCost As Decimal

        ' Get and validate the number of people
        numPeople = CInt(InputBox("Enter the number of people in the group (1 - 50):"))
        While numPeople < 1 OrElse numPeople > 50
            MessageBox.Show("Please enter a number between 1 and 50.", "Invalid Input")
            numPeople = CInt(InputBox("Enter the number of people in the group (1 - 50):"))
        End While

        ' Determine the rate per person using Select Case
        Select Case numPeople
            Case 1 To 4
                ratePerPerson = 10D
            Case 5 To 9
                ratePerPerson = 9D
            Case 10 To 14
                ratePerPerson = 8D
            Case 15 To 19
                ratePerPerson = 7D
            Case Else
                ratePerPerson = 5D
        End Select

        ' Calculate the total meal plan cost
        mealPlanCost = numPeople * ratePerPerson

        ' Display the cost per person in a MessageBox
        MessageBox.Show("Meal Plan Rate: $" & ratePerPerson.ToString("F2") & " per person", "Rate Per Person")

        ' Update the meal plan total in the appropriate textbox
        txtOptional.Text = "Meal Plan: $" & mealPlanCost.ToString("F2")
    End Sub











    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        txtNumNights.Clear()
        txtOptional.Clear()
        txtSub.Clear()
        txtWithout.Clear()
        txtTaxes.Clear()




    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Me.Close()


    End Sub

    Private Sub CboSite_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboSite.SelectedIndexChanged

        ' Show controls when a site is selected
        If CboSite.SelectedIndex <> -1 Then

            lblNumNights.Visible = True
            txtNumNights.Visible = True



        End If



    End Sub

End Class






