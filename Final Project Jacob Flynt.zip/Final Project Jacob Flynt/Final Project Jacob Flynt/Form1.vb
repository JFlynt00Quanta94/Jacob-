﻿Imports System.Reflection.Metadata.Ecma335

Public Class Form1
    Private Sub BtnCalculate_Click(sender As Object, e As EventArgs) Handles BtnCalculate.Click

        Dim sitePrice As Decimal = 0D
        Dim nights As Integer = 0
        Dim discount As Decimal = 0D
        Dim subtotal As Decimal = 0D
        Dim taxRate As Decimal = 0.065D
        Dim mealPlanCost As Decimal = 0D
        Dim finalTotalWithoutMealPlan As Decimal = 0D
        Dim finalTotalWithMealPlan As Decimal = 0D
        Dim taxamount As Decimal = 0D


        'TO DO: remove ALL comments, fix meal plan adding to total

        nights = CDec(txtNumNights.Text)



        Dim tents As Decimal = 30D
        Dim RV As Decimal = 50D
        Dim Cabin As Decimal = 100D


        If CboSite.SelectedIndex = 0 Then
            sitePrice = 30D
        ElseIf CboSite.SelectedIndex = 2 Then
            sitePrice = 50D
        ElseIf CboSite.SelectedIndex = 4 Then
            sitePrice = 100D
        End If

        If radAAA.Checked Then
            discount = 0.1D
        ElseIf radMilitary.Checked Then
            discount = 0.12D
        ElseIf radNone.Checked Then
            discount = 0D
        End If

        subtotal = sitePrice * nights * (1 - discount)

        taxamount = subtotal * taxRate


        finalTotalWithoutMealPlan = subtotal + taxamount
        finalTotalWithMealPlan = finalTotalWithoutMealPlan + mealPlanCost


        subtotal = Math.Round(subtotal, 2)
        taxamount = Math.Round(taxamount, 2)
        mealPlanCost = Math.Round(mealPlanCost, 2)
        finalTotalWithoutMealPlan = Math.Round(finalTotalWithoutMealPlan, 2)
        finalTotalWithMealPlan = Math.Round(finalTotalWithMealPlan, 2)


        txtSub.Visible = True
        txtTaxes.Visible = True
        txtWithout.Visible = True
        lblSub.Visible = True
        lblTaxes.Visible = True
        lblWithout.Visible = True
        lblOptional.Visible = True
        txtOptional.Visible = True

        txtSub.Text = "Subtotal: " & subtotal.ToString("C")
        txtTaxes.Text = "Taxes: " & taxamount.ToString("C")
        txtWithout.Text = "Final Total: " & finalTotalWithoutMealPlan.ToString("C")
        txtOptional.Text = "Meal Plan: " & mealPlanCost.ToString("C")
        txtOptional.Text = "Final Total: " & finalTotalWithMealPlan.ToString("C")



    End Sub




    Private Sub BtnMeal_Click(sender As Object, e As EventArgs) Handles BtnMeal.Click

        Dim numPeople As Integer
        Dim ratePerPerson As Decimal
        Dim mealPlanCost As Decimal

        numPeople = CInt(InputBox("Enter the number of people in the group (1 - 50):"))
        While numPeople < 1 Or numPeople > 50
            MessageBox.Show("Please enter a number between 1 and 50.", "Invalid Input")
            numPeople = CInt(InputBox("Enter the number of people in the group (1 - 50):"))
        End While


        Select Case numPeople
            Case 1 To 4
                ratePerPerson = 10D
            Case 5 To 9
                ratePerPerson = 9D
            Case 10 To 14
                ratePerPerson = 8D
            Case 15 To 19
                ratePerPerson = 7D
            Case Else
                ratePerPerson = 5D
        End Select

        mealPlanCost = numPeople * ratePerPerson

        MessageBox.Show("Meal Plan Rate: " & ratePerPerson.ToString("C") & " per person", "Rate Per Person")

        txtOptional.Text = "Meal Plan: " & mealPlanCost.ToString("C")
    End Sub


    Function RateOfTax(amount As Decimal) As Decimal

        Dim taxRate As Decimal = 6.5D
        Dim tax As Decimal = amount * taxRate
        Return tax

    End Function


    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        txtNumNights.Clear()
        txtOptional.Clear()
        txtSub.Clear()
        txtWithout.Clear()
        txtTaxes.Clear()
        CboSite.Text = ""

        radAAA.Checked = False
        radMilitary.Checked = False
        radNone.Checked = False




    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Me.Close()


    End Sub

    Private Sub CboSite_SelectedIndexChanged(sender As Object, e As EventArgs) Handles CboSite.SelectedIndexChanged



        If CboSite.SelectedIndex <> -1 Then

            lblNumNights.Visible = True
            txtNumNights.Visible = True



        End If



    End Sub

    Private Sub txtNumNights_TextChanged(sender As Object, a As EventArgs) Handles txtNumNights.TextChanged

        If (IsNumeric(txtNumNights.Text)) Then
            grpDiscounts.Visible = True
        Else
            MessageBox.Show("Nights must be a number")
        End If





    End Sub


    Private Sub radAAA_CheckedChanged(sender As Object, a As EventArgs) Handles radAAA.CheckedChanged, radMilitary.CheckedChanged, radNone.CheckedChanged

        If radAAA.Checked Or radMilitary.Checked Or radNone.Checked Then



            BtnCalculate.Visible = True
            BtnMeal.Visible = True
            btnClear.Visible = True
            btnExit.Visible = True


        End If


    End Sub



    Function NightsCheckInt(ByVal input As String) As Boolean
        Try
            Convert.ToInt32(input)
            Return True
        Catch ex As Exception
            Return False
        End Try


    End Function





End Class












